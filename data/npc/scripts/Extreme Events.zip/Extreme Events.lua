local keywordHandler = KeywordHandler:new() 
local npcHandler = NpcHandler:new(keywordHandler) 
NpcSystem.parseParameters(npcHandler) 
local talkState = {} 
function onCreatureAppear(cid) npcHandler:onCreatureAppear(cid) end 
function onCreatureDisappear(cid) npcHandler:onCreatureDisappear(cid) end 
function onCreatureSay(cid, type, msg) npcHandler:onCreatureSay(cid, type, msg) end 
function onThink() npcHandler:onThink() end 
function creatureSayCallback(cid, type, msg) 
	if(not npcHandler:isFocused(cid)) then 
		return false 
	end 
	local talkUser,msg,str = NPCHANDLER_CONVbehavior == CONVERSATION_DEFAULT and 0 or cid,msg:lower(),""
	local moeda = 6527 -- ID DA SILVER TOKEN 
	local t = {
		["extreme moon backpack"] = {amount = 400, item = {12738,1}},
		["extreme heart backpack"] = {amount = 40, item = {12739,1}},
		["extreme santa backpack"] = {amount = 400, item = {12740,1}},
		["pair of soft boots"] = {amount = 150, item = {2640,1}},
		["ferumbras'hat"] = {amount = 1800, item = {5903,1}},
		["dragon claw"] = {amount = 30, item = {5919,1}},
		["mandrake"] = {amount = 100, item = {5015,1}},
		["nose ring"] = {amount = 100, item = {5804,1}},
		["soul stone"] = {amount = 100, item = {5809,1}},
		["brutus bloodbeard"] = {amount = 50, item = {6099,1}},
		["the lethal lissy's shirt"] = {amount = 100, item = {6100,2}}
	}

	if (msgcontains(msg, 'trade') or msgcontains(msg, 'TRADE'))then
		str = str .. "Pode trocar suas SILVER TOKENS por: "
		for name, ret in pairs(t) do
			str = str.." {"..name.."} = "..ret.amount.." Moedas /"
		end
		npcHandler:say(str, cid)
	elseif t[msg] then
		local item, amount = t[msg].item[1], t[msg].item[2]
		if doPlayerRemoveItem(cid,moeda, t[msg].amount) then
			if isItemStackable(item) or amount == 1 then
				doPlayerAddItem(cid, item, amount)
			else
				for i = 1, amount do
					doPlayerAddItem(cid, item, 1)
				end
			end
			npcHandler:say("Aqui está "..amount.." ".. getItemNameById(item) .."!", cid)
		else
			npcHandler:say("Você precisa de "..t[msg].amount.." ".. getItemNameById(moeda), cid)
		end
	end 
	return true 
end
npcHandler:setCallback(CALLBACK_MESSAGE_DEFAULT, creatureSayCallback) 
npcHandler:addModule(FocusModule:new())